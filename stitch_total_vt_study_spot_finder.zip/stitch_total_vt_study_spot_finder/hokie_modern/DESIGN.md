```markdown
# Design System Strategy: The Academic Atelier

## 1. Overview & Creative North Star
The Creative North Star for this design system is **"The Academic Atelier."** 

Standard educational apps often feel like digitised filing cabinets—rigid, cold, and utilitarian. This design system rejects that. Instead, it creates a high-end, editorial space that mirrors a premium university library: a place of quiet focus, tactile quality, and intellectual prestige. We achieve this through a "High-End Editorial" lens, prioritising intentional asymmetry, generous white space, and a rejection of standard "app-like" containerization. 

The layout should feel like a bespoke journal. We break the template by using overlapping elements where titles bleed slightly into image containers, and by utilizing a high-contrast typography scale that establishes a clear, authoritative information hierarchy.

## 2. Colors
Our palette is rooted in the heritage of 'Chicago Maroon' and 'Burnt Orange,' but we elevate these from mere school colors to a sophisticated brand identity through tonal depth and modern application.

### The Palette
*   **Primary Focus:** `primary` (#690008) and `primary_container` (#8B1A1A). These are our anchors. Use the container variant for large-scale brand moments and the core primary for high-action touchpoints.
*   **Secondary Accents:** `secondary` (#994700) and `secondary_container` (#FF8934). These are used sparingly for progress indicators or specific "Active" states to provide a warm, energetic contrast to the deep maroon.
*   **Neutral Depth:** We rely on a sophisticated range of greys from `surface` (#F9F9F9) to `surface_container_highest` (#E2E2E2) to create a focused study environment.

### The "No-Line" Rule
To maintain an editorial feel, **1px solid borders are prohibited for sectioning.** Do not use lines to separate content. Boundaries must be defined through background color shifts. For example, a `surface_container_low` card should sit on a `surface` background to define its edges.

### Surface Hierarchy & Nesting
Treat the UI as physical layers of fine paper. 
*   **Base:** `surface` (#F9F9F9).
*   **Sub-sections:** `surface_container_low`.
*   **Interactive Cards:** `surface_container_lowest` (Pure White).
Nesting these levels creates organic depth without the visual "noise" of traditional grids.

### The "Glass & Gradient" Rule
To avoid a "flat" or generic look, use **Glassmorphism** for floating elements (like bottom navigation or top app bars). Utilize the `surface` color at 80% opacity with a `20px` backdrop-blur. 
*   **Signature Gradients:** Apply a subtle linear gradient from `primary` (#690008) to `primary_container` (#8B1A1A) on hero buttons and progress tracks to add "soul" and professional polish.

## 3. Typography
We use a dual-typeface system to balance authority with readability.

*   **Display & Headlines (Manrope):** This is our "Editorial Voice." `display-lg` through `headline-sm` use Manrope to provide a modern, geometric, and professional character. Use these for section headers and "Big Data" moments (like a GPA display or a Countdown).
*   **Body & Titles (Inter):** For everything else, we use Inter. It is the gold standard for legibility in academic contexts. 
*   **Hierarchy as Identity:** Use `display-md` for page titles with extreme tracking (letter spacing) reductions (-2%) to create a dense, premium "magazine" feel. Combine this with `body-md` for descriptions to create a striking visual contrast.

## 4. Elevation & Depth
In this system, depth is felt, not seen. We move away from heavy shadows toward **Tonal Layering.**

### The Layering Principle
Place a `surface_container_lowest` card on a `surface_container_low` background. The subtle shift in hex code provides enough contrast for the human eye to perceive "lift" without the need for a drop shadow.

### Ambient Shadows
When a component must float (e.g., a FAB or a modal), use an **Ambient Shadow**:
*   **Color:** Use a 6% opacity version of `on_surface` (#1A1C1C).
*   **Blur:** 24px to 32px.
*   **Spread:** -4px.
This creates a soft, natural glow that mimics soft studio lighting rather than a harsh digital shadow.

### The "Ghost Border" Fallback
If accessibility requirements (WCAG) demand a container edge, use a **Ghost Border**: `outline_variant` (#E0BFBC) at 20% opacity. Never use 100% opaque borders.

## 5. Components

### Buttons
*   **Primary:** Rounded `xl` (1.5rem). Use the Maroon gradient (`primary` to `primary_container`). Typography: `label-md` in `on_primary`.
*   **Secondary:** Ghost style. No background, `outline_variant` Ghost Border (20% opacity). Typography: `primary` color.
*   **Tertiary:** Text only, bolded `label-md` in `primary`.

### Cards & Lists
*   **Forbid Dividers:** Never use a line between list items. Use 16px of vertical white space or alternate background tones (`surface` to `surface_container_low`).
*   **Rounding:** All cards must use `lg` (1rem) or `xl` (1.5rem) corner radii to feel approachable and modern.

### Input Fields
*   **Style:** Filled, not outlined. Use `surface_container_high` as the field background.
*   **Active State:** Transition the background to `surface_container_lowest` and add a 1px `primary` Ghost Border. 

### Chips
*   **Academic Tags:** Use `secondary_fixed` (#FFDBC8) backgrounds with `on_secondary_fixed` (#321300) text. These should feel like high-end "labels" found in a library.

### Course Progress (Custom Component)
*   **The "Hokie Track":** A thick, 8px horizontal bar using `surface_container_highest` as the track and a gradient of `secondary` to `secondary_container` as the fill.

## 6. Do's and Don'ts

### Do:
*   **Embrace Asymmetry:** Offset your headline from your body text by a few pixels to create an editorial flow.
*   **Use White Space as a Tool:** If a screen feels "busy," do not add lines; add 24px of padding.
*   **Tonal Consistency:** Ensure that text on maroon backgrounds always uses `on_primary` (#FFFFFF) for AA+ accessibility.

### Don't:
*   **No "Pure Black":** Never use #000000. Use `on_surface` (#1A1C1C) for all "black" text to keep the interface feeling soft and academic.
*   **No Standard Shadows:** Avoid the "Material Design 2" look of heavy, dark shadows.
*   **No Borders:** If you reach for a border tool, ask if a background color shift could do the job better.